

public class empleadoHIJO extends empleado {


    public empleadoHIJO(String nombre, String identificacion, double salarioBase) {
        super(nombre, identificacion, salarioBase);
    }

    @Override
    public double calcularPago() {
        return salarioBase;
    }

    @Override
    public double calcularDescuento() {
        return 0;
    }
}