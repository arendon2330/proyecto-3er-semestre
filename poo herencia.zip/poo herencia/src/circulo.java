

public class circulo extends figura {

    private double radio;

    // Constructor vacío
    public circulo() {
    }

    // Constructor con parámetros (Corregido: ahora recibe e inicializa el radio)
    public circulo(String nombre, String color, double radio) {
        super(nombre, color);
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    @Override
    public String toString() {
        return super.toString() + " circulo{" +
                "radio=" + radio +
                '}';
    }

    // Corregido: Usa el atributo de la clase 'this.radio'
    @Override
    public double calcularArea() {
        return Math.PI * Math.pow(this.radio, 2);
    }

    // Corregido: Calculo correcto usando el atributo
    @Override
    public double calcularPerimetro() {
        return 2 * Math.PI * this.radio;
    }

    // Corregido: Eliminada la 'base' y ajustados los accesores/variables
    public void mostrarInformacion() {
        System.out.println("Nombre: " + getNombre());
        System.out.println("Color: " + getColor());
        System.out.println("Radio: " + this.radio);
        System.out.println("Área: " + calcularArea());
        System.out.println("Perímetro: " + calcularPerimetro());
    }
}