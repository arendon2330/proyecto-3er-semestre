

public class figura {
    protected String nombre;
    protected String color;


    public figura() {
    }

    public figura(String nombre, String color) {
        this.nombre = nombre;
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String toString() {
        return "figura{" +
                "nombre='" + nombre + '\'' +
                ", color=" + color +
                '}';
    }
    public double calcularArea(){
        return 0;
    }
    public double calcularPerimetro() {
        return 0;
    }
    public void mostrarInformacion(){
        System.out.println("nombre" + nombre);
        System.out.println("color" + color);
    }
}
