
public class Main {

    public static void main(String[] args) {

        // Instanciación de objetos usando el orden correcto de parámetros
        rectangulo r1 = new rectangulo("R1", "AZUL", 23.5, 12.6);
        circulo c1 = new circulo("C1", "rojo", 26.4);
        triangulo T1 = new triangulo("T1", "morado", 24.9, 14.9, 23.16);

        // Uso de Rectángulo
        System.out.println("=== SOY UN RECTÁNGULO ===");
        System.out.println("Área: " + r1.calcularArea());
        System.out.println("Perímetro: " + r1.calcularPerimetro());
        r1.mostrarInformacion();

        System.out.println(); // Línea en blanco para separar

        // Uso de Círculo
        System.out.println("=== SOY UN CÍRCULO ===");
        System.out.println("Área: " + c1.calcularArea());
        System.out.println("Perímetro: " + c1.calcularPerimetro());
        c1.mostrarInformacion();

        System.out.println(); // Línea en blanco para separar

        // Uso de Triángulo
        System.out.println("=== SOY UN TRIÁNGULO ===");
        System.out.println("Área: " + T1.calcularArea());
        System.out.println("Perímetro: " + T1.calcularPerimetro());
        T1.mostrarInformacion();
    }
}