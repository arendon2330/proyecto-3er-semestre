public class rectangulo extends figura {

    private double base;
    private double altura;

    public rectangulo(String r1, String azul, double base, double altura) {
    }

    public rectangulo(String nombre, System color, double base, double altura) {
        super(nombre, color.toString());
        this.base = base;
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return super.toString() +   "rectangulo{" +
                "base=" + base +
                ", altura=" + altura +
                '}';
    }

    public double calcularArea() {
        return base * altura;

    }

    @Override
    public double calcularPerimetro() {
        return (2 * base + altura);
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("nombre" + nombre);
        System.out.println("color" + color);
        System.out.println("Base" + base);
        System.out.println("Altura" + altura);
    }

}