public class VEHICULO {
    private String PLACA;
    private String MARCA;
    private int MODELO;
    private double KmRECORRIDOS;
    private double LITROSCONSUMIDOS;
    private double PRECIOLITROS;
    private boolean ACTIVO;

    public VEHICULO() {
    }

    public VEHICULO(String PLACA, String MARCA, int MODELO, double kmRECORRIDOS,
                    double LITROSCONSUMIDOS, double PRECIOLITROS, boolean ACTIVO) {
        this.PLACA = PLACA;
        this.MARCA = MARCA;
        this.MODELO = MODELO;
        KmRECORRIDOS = kmRECORRIDOS;
        this.LITROSCONSUMIDOS = LITROSCONSUMIDOS;
        this.PRECIOLITROS = PRECIOLITROS;
        this.ACTIVO = ACTIVO;
    }

    public String getPLACA() {
        return PLACA;
    }

    public void setPLACA(String PLACA) {
        this.PLACA = PLACA;
    }

    public String getMARCA() {
        return MARCA;
    }

    public void setMARCA(String MARCA) {
        this.MARCA = MARCA;
    }

    public int getMODELO() {
        return MODELO;
    }

    public void setMODELO(int MODELO) {
        this.MODELO = MODELO;
    }

    public double getKmRECORRIDOS() {
        return KmRECORRIDOS;
    }

    public void setKmRECORRIDOS(double kmRECORRIDOS) {
        KmRECORRIDOS = kmRECORRIDOS;
    }

    public double getLITROSCONSUMIDOS() {
        return LITROSCONSUMIDOS;
    }

    public void setLITROSCONSUMIDOS(double LITROSCONSUMIDOS) {
        this.LITROSCONSUMIDOS = LITROSCONSUMIDOS;
    }

    public double getPRECIOLITROS() {
        return PRECIOLITROS;
    }

    public void setPRECIOLITROS(double PRECIOLITROS) {
        this.PRECIOLITROS = PRECIOLITROS;
    }

    public boolean isACTIVO() {
        return ACTIVO;
    }

    public void setACTIVO(boolean ACTIVO) {
        this.ACTIVO = ACTIVO;
    }

    @Override
    public String toString() {
        return "poo{" +
                "PLACA='" + PLACA + '\'' +
                ", MARCA='" + MARCA + '\'' +
                ", MODELO=" + MODELO +
                ", KmRECORRIDOS=" + KmRECORRIDOS +
                ", LITROSCONSUMIDOS=" + LITROSCONSUMIDOS +
                ", PRECIOLITROS=" + PRECIOLITROS +
                ", ACTIVO=" + ACTIVO +
                '}';


    }

    public double CalcularRendimiento() {
        return KmRECORRIDOS / LITROSCONSUMIDOS;
    }

    String ClasificarRendimiento() {
        double rendimiento = CalcularRendimiento();
        if (rendimiento < 8) {
            return "CONSUMO ALTO";
        } else if (rendimiento < 12) {
            return "CONSUMO MODERADO";
        } else if (rendimiento < 16) {
            return "CONSUMO EFICIENTE";
        }else if (rendimiento >= 16){
            return "CONSUMO MUY EFICIENTE";
        }

        double calcularCostoDeCombustible;
                {
            return LITROSCONSUMIDOS * PRECIOLITROS;
        }

         double CostoPorKilometro;
        {
            return String.valueOf(calcularCostoDeCombustible / KmRECORRIDOS);
        }

        boolean ActualizarKilometraje; double NuevosKilometros; {
            if (NuevosKilometros > 0) {
                KmRECORRIDOS = NuevosKilometros;
                return String.valueOf(true);
            }
            return String.valueOf(false);
    }

        boolean NecesitaRevision; {
            return String.valueOf(CalcularRendimiento() < 8);
        }

        String generarRecomendacion;{
            String clasificacion = ClasificarRendimiento();
            return switch (clasificacion) {
                case "Consumo alto" -> "Revisar motor y sistema de combustible";
                case "Consumo moderado" -> "Revisar hábitos de conducción";
                case "Consumo eficiente" -> "El vehículo presenta buen rendimiento";
                case "Consumo muy eficiente" -> "Excelente rendimiento";
                default -> "Sin recomendación";
            };

        }
}
}






