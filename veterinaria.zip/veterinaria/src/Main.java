//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {

        Perro perro1 = new Perro("Max", 5, 12, "Carlos Pérez", "Labrador");

        Perro perro2 = new Perro("Rocky", 4, 10, "Juan Rodríguez", "Pastor Alemán");


        Gato gato1 = new Gato("Luna", 3, 4, "Laura Gómez", "Interior");

        Gato gato2 = new Gato("Milo", 2, 5, "Ana Martínez", "Exterior");


        System.out.println(perro1);
        System.out.println();

        System.out.println(perro2);
        System.out.println();

        System.out.println(gato1);
        System.out.println();

        System.out.println(gato2);
    }


