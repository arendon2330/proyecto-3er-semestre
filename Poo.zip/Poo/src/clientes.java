public class clientes {

    private String id;
    private String nombre;
    private int edad;
    private double peso;
    private double altura;

    public clientes(String id) {
    }

    public clientes(String id,
                    String nombre,
                    int edad,
                    double peso,
                    double altura) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
    }

    {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "clientes " +
                "id = " + id +
                ", nombre = " + nombre +
                ", edad = " + edad +
                ", peso = " + peso +
                ", altura = " + altura +
                '}';
    }

    public double calcularIMC() {
        return peso / (altura * altura);

    }

    public String clasificarIMC() {
        double imc = calcularIMC();
        String situacion;

        if (imc < 18.5) {
            situacion = "PESO BAJO";
        } else if (imc < 25) {
            situacion = "PESO NORMAL";
        } else if (imc < 30) {
            situacion = "SOBRE PESO";
        } else {
            situacion = "OBECIDAD";

        }
        return situacion;
}

    public boolean actualizarpeso(double nuevopeso){
        if(nuevopeso > 0) {
            peso = nuevopeso;
            return true;
        }else{
            return false;
                    }
                }
            }
